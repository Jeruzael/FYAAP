Note of the author
this font is demo version, only free for personal use.

if you want to extended licenses, send me a message
only via email : debutstudio21@gmail.com

or you can buy it from www.debutstudio.net

Thanks!

---

INDONESIA - MOHON DIBACA:
Buat teman-teman yang di Indonesia, harap maklum bahwa font ini adalah GRATIS namun hanya untuk KEPERLUAN PRIBADI, yang artinya bukan dipakai untuk keperluan komersial yang uangnya ente makan sendiri, seperti poster filem, pamflet promo, logo perusahaan, kaos,
dan sejenisnya
minimal bagi-bagi dengan saya si pemilik font ini dengan cara membeli lisensi Commercial Use, atau lisensi yang lebih besar lagi penggunaannya yaitu Lisensi Extended, jangan nanti saat sudah terciduk, baru mengaku tidak paham lalu melarikan diri :D

Silahkan hubungi saya via email :
debutstudio21@gmail.com

Happy Designing!