/*window.onscroll = function(){headerH()};

function headerH(){

	if(document.documentElement.scrollTop > 50){
		document.getElementByTagName("header").style.height = "green";
	alert("working!~");
	}else{
		alert("not working!~");
	}
	
}